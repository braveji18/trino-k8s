# starrocks-helm-kustomize

StarRocks operator의 **공식 Helm 차트를 Kustomize로 감싸(inflation)** 확장하는 구조.

## 핵심
- `charts/kube-starrocks/` : 원본 helm 차트 벤더링 (CRD는 실체 파일로 교체)
- `base/` : `helmCharts:` 로 차트를 inflation + `values.yaml`
- `overlays/<env>/` : helm 렌더 결과에 patch
- `argocd/` : Application + `argocd-cm` (--enable-helm)

## 로컬 검증
```bash
kustomize build --enable-helm base
kustomize build --enable-helm overlays/prod
```

## ArgoCD 전제조건
repo-server 가 kustomize 빌드 중 helm 을 호출하도록 argocd-cm 에
`kustomize.buildOptions: --enable-helm` 설정 필요. (argocd/argocd-cm-enable-helm.yaml)
