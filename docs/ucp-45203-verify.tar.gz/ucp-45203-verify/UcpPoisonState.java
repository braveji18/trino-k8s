import oracle.jdbc.pool.OracleDataSource;
import oracle.ucp.jdbc.PoolDataSource;
import oracle.ucp.jdbc.PoolDataSourceFactory;

import java.lang.reflect.Field;
import java.util.Properties;

/**
 * 실험 2: "풀 생성 도중 Error(OOM 등) 발생" 상태가 UCP-45203을 만드는지 검증.
 *
 * 배경: UCP의 PoolDataSourceImpl.createUniversalConnectionPool()은 풀 객체를
 * 먼저 할당하고 맨 마지막에 자격증명 정보(ConnectionRetrievalInfo, CRI)를 설정하는데,
 * 실패 정리 코드가 catch (Exception)이라 OutOfMemoryError 같은 Error는 잡지 못한다.
 * 그 사이에 Error가 발생하면 "풀 객체는 있으나 CRI가 null"인 상태가 남는다.
 *
 * 이 프로그램은 그 상태를 리플렉션으로 정확히 재현한 뒤, 이후의 모든 getConnection이
 *   UCP-0: Unable to start the Universal Connection Pool
 *     <- Caused by: UCP-45203: The Connection Request Info is null
 * 로 영구 실패함을 보인다. user/password가 정상 설정되어 있어도 발생한다.
 *
 * 사용법: java UcpPoisonState <port>   (port는 fake_listener drop 모드 포트)
 */
public class UcpPoisonState
{
    public static void main(String[] args)
            throws Exception
    {
        PoolDataSource dataSource = PoolDataSourceFactory.getPoolDataSource();
        dataSource.setConnectionFactoryClassName(OracleDataSource.class.getName());
        dataSource.setURL("jdbc:oracle:thin:@//127.0.0.1:" + args[0] + "/ORCL");
        dataSource.setInitialPoolSize(1);
        dataSource.setMinPoolSize(1);
        dataSource.setMaxPoolSize(10);
        dataSource.setValidateConnectionOnBorrow(true);
        Properties props = new Properties();
        props.setProperty("oracle.net.CONNECT_TIMEOUT", "1500");
        dataSource.setConnectionProperties(props);
        dataSource.setUser("trino_user");        // 자격증명 정상 설정 상태
        dataSource.setPassword("secret");

        // 1차 시도: 풀 객체 생성됨, 과부하 리스너 때문에 기동은 실패 (UCP-45257 계열)
        try {
            dataSource.getConnection();
        }
        catch (Throwable t) {
            System.out.println("1차 시도 (과부하 중):   " + chain(t));
        }

        // Error 창(window) 시뮬레이션: 풀 객체 할당 후 CRI 설정 전에 OOM이 발생한 상태.
        // (실제로는 UCP의 catch(Exception)이 Error를 놓쳐서 이 상태가 남는다)
        Object pool = readField(dataSource, "connectionPool");
        Field criField = Class.forName("oracle.ucp.common.UniversalConnectionPoolBase")
                .getDeclaredField("defaultConnectionRetrievalInfo");
        criField.setAccessible(true);
        criField.set(pool, null);
        System.out.println("-- 풀 오염 주입: defaultConnectionRetrievalInfo = null (풀 생성 중 OOM 후와 동일 상태) --");

        // 2차 이후: DB가 정상으로 돌아와도 무관하게 UCP-45203이 영구 반복되는지 확인
        for (int i = 2; i <= 3; i++) {
            try {
                dataSource.getConnection();
                System.out.println(i + "차 시도: 예상 밖 성공");
            }
            catch (Throwable t) {
                System.out.println(i + "차 시도 (과부하 이후): " + chain(t));
            }
        }
    }

    static Object readField(Object o, String name)
            throws Exception
    {
        Class<?> c = o.getClass();
        while (c != null) {
            try {
                Field f = c.getDeclaredField(name);
                f.setAccessible(true);
                return f.get(o);
            }
            catch (NoSuchFieldException e) {
                c = c.getSuperclass();
            }
        }
        throw new NoSuchFieldException(name);
    }

    static String chain(Throwable e)
    {
        StringBuilder sb = new StringBuilder();
        while (e != null) {
            sb.append(e.getClass().getSimpleName()).append(": ").append(String.valueOf(e.getMessage()).split("\n")[0]);
            e = e.getCause();
            if (e != null) {
                sb.append("  <- Caused by: ");
            }
        }
        return sb.toString();
    }
}
