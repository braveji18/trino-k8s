import io.airlift.units.Duration;
import io.opentelemetry.api.OpenTelemetry;
import io.trino.plugin.jdbc.credential.StaticCredentialProvider;
import io.trino.plugin.oracle.OraclePoolConnectionFactory;

import java.lang.reflect.Field;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

// 패치된 OraclePoolConnectionFactory의 자가 복구(UCP-45203 감지 -> 풀 재생성) 검증.
// 1) 과부하 리스너에 대해 정상 실패(UCP-45257) 확인
// 2) 풀 오염 주입 (풀 생성 중 Error가 남기는 상태)
// 3) 다시 openConnection -> 패치 전: UCP-45203 영구 / 패치 후: 풀 교체 후 45203 아닌 에러(45257)로 복귀
public class PatchVerify
{
    public static void main(String[] args)
            throws Exception
    {
        Properties props = new Properties();
        props.setProperty("oracle.net.CONNECT_TIMEOUT", "1500");
        OraclePoolConnectionFactory factory = new OraclePoolConnectionFactory(
                "jdbc:oracle:thin:@//127.0.0.1:" + args[0] + "/ORCL",
                props,
                StaticCredentialProvider.of("trino_user", "secret"),
                1,
                10,
                new Duration(20, TimeUnit.MINUTES),
                OpenTelemetry.noop());

        // 1차: 풀 객체 생성 + 과부하로 기동 실패
        try {
            factory.openConnection(null);
        }
        catch (Throwable t) {
            System.out.println("1차 (과부하 중):    " + chain(t));
        }

        // 풀 오염 주입 (풀 생성 도중 OOM이 남기는 상태와 동일)
        Object otelDataSource = readField(factory, "dataSource");
        Object poolDataSource = findDataSourceDelegate(otelDataSource);
        Object pool = readField(poolDataSource, "connectionPool");
        Field criField = Class.forName("oracle.ucp.common.UniversalConnectionPoolBase")
                .getDeclaredField("defaultConnectionRetrievalInfo");
        criField.setAccessible(true);
        criField.set(pool, null);
        System.out.println("-- 풀 오염 주입 완료 --");

        // 2차/3차: 자가 복구 검증
        boolean recovered = true;
        for (int i = 2; i <= 3; i++) {
            try {
                factory.openConnection(null);
                System.out.println(i + "차: 예상 밖 성공");
            }
            catch (Throwable t) {
                String chain = chain(t);
                System.out.println(i + "차 (오염 이후):    " + chain);
                if (chain.contains("45203")) {
                    recovered = false;
                }
            }
        }
        Object newDataSource = readField(factory, "dataSource");
        System.out.println();
        System.out.println("풀 교체 여부: " + (newDataSource != otelDataSource ? "교체됨 (자가 복구 동작)" : "교체 안 됨"));
        System.out.println(recovered && newDataSource != otelDataSource
                ? "검증 성공: UCP-45203 오염이 자동 복구되어 일시적 에러(45257)로 돌아옴"
                : "검증 실패: 오염이 지속됨");
    }

    static Object findDataSourceDelegate(Object wrapper)
            throws Exception
    {
        for (Field f : wrapper.getClass().getDeclaredFields()) {
            if (javax.sql.DataSource.class.isAssignableFrom(f.getType())) {
                f.setAccessible(true);
                return f.get(wrapper);
            }
        }
        throw new IllegalStateException("no DataSource delegate in " + wrapper.getClass());
    }

    static Object readField(Object o, String name)
            throws Exception
    {
        Class<?> c = o.getClass();
        while (c != null) {
            try {
                Field f = c.getDeclaredField(name);
                f.setAccessible(true);
                return f.get(o);
            }
            catch (NoSuchFieldException e) {
                c = c.getSuperclass();
            }
        }
        throw new NoSuchFieldException(name);
    }

    static String chain(Throwable e)
    {
        StringBuilder sb = new StringBuilder();
        while (e != null) {
            sb.append(e.getClass().getSimpleName()).append(": ").append(String.valueOf(e.getMessage()).split("\n")[0]);
            e = e.getCause();
            if (e != null) {
                sb.append("  <- Caused by: ");
            }
        }
        return sb.toString();
    }
}
