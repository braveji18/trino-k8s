import oracle.jdbc.pool.OracleDataSource;
import oracle.ucp.jdbc.PoolDataSource;
import oracle.ucp.jdbc.PoolDataSourceFactory;

import java.util.Properties;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 실험 1: 순수 과부하(리스너 다운/드롭/행)만으로 UCP-45203이 발생하는지 검증.
 *
 * Trino의 OraclePoolConnectionFactory와 동일하게 PoolDataSource를 구성하고
 * (user/password 정상 설정), 동시 다발 getConnection을 여러 라운드 반복한다.
 *
 * 기대 결과: UCP-0 -> UCP-45257 -> ORA-* 만 발생, UCP-45203은 0건.
 * (즉, 네트워크/리스너 과부하 자체는 45203의 원인이 아님)
 *
 * 사용법: java UcpOverloadRepro <port> <동시스레드수> <라운드수>
 */
public class UcpOverloadRepro
{
    public static void main(String[] args)
            throws Exception
    {
        int port = Integer.parseInt(args[0]);
        int threads = Integer.parseInt(args[1]);
        int rounds = Integer.parseInt(args[2]);

        // Trino OraclePoolConnectionFactory와 동일 구성
        PoolDataSource dataSource = PoolDataSourceFactory.getPoolDataSource();
        dataSource.setConnectionFactoryClassName(OracleDataSource.class.getName());
        dataSource.setURL("jdbc:oracle:thin:@//127.0.0.1:" + port + "/ORCL");
        dataSource.setInitialPoolSize(1);
        dataSource.setMinPoolSize(1);
        dataSource.setMaxPoolSize(10);
        dataSource.setValidateConnectionOnBorrow(true);
        Properties props = new Properties();
        props.setProperty("oracle.net.CONNECT_TIMEOUT", "1500");
        props.setProperty("oracle.jdbc.ReadTimeout", "1500");
        dataSource.setConnectionProperties(props);
        dataSource.setInactiveConnectionTimeout(1200);
        dataSource.setUser("trino_user");
        dataSource.setPassword("secret");

        AtomicInteger count45203 = new AtomicInteger();
        AtomicInteger countOther = new AtomicInteger();

        for (int round = 0; round < rounds; round++) {
            ExecutorService pool = Executors.newFixedThreadPool(threads);
            CountDownLatch ready = new CountDownLatch(threads);
            CountDownLatch go = new CountDownLatch(1);
            for (int t = 0; t < threads; t++) {
                pool.submit(() -> {
                    ready.countDown();
                    try {
                        go.await();
                        dataSource.getConnection().close();
                        System.out.println("UNEXPECTED SUCCESS");
                    }
                    catch (Exception e) {
                        String chain = chain(e);
                        if (chain.contains("45203") || chain.contains("Request Info is null")) {
                            count45203.incrementAndGet();
                            System.out.println("*** UCP-45203 발생! " + chain);
                        }
                        else {
                            countOther.incrementAndGet();
                            System.out.println("  " + chain);
                        }
                    }
                    return null;
                });
            }
            ready.await();
            go.countDown();
            pool.shutdown();
            pool.awaitTermination(60, TimeUnit.SECONDS);
            System.out.println("round " + round + " 완료. 45203=" + count45203.get() + " 기타=" + countOther.get());
        }
        System.out.println("최종: UCP-45203=" + count45203.get() + "건, 기타 에러=" + countOther.get() + "건");
    }

    static String chain(Throwable e)
    {
        StringBuilder sb = new StringBuilder();
        while (e != null) {
            sb.append(e.getClass().getSimpleName()).append(": ").append(String.valueOf(e.getMessage()).split("\n")[0]);
            e = e.getCause();
            if (e != null) {
                sb.append("  <- Caused by: ");
            }
        }
        return sb.toString();
    }
}
