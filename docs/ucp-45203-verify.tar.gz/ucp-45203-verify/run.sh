#!/usr/bin/env bash
# UCP-45203 검증 실험 실행 스크립트
#
# 필요: java 17+ (javac 포함된 JDK), python3, curl
# jar 준비: 아래 둘 중 하나
#   1) 운영 Trino의 plugin/oracle/ 디렉토리에서 복사 (운영과 동일 버전으로 검증 - 권장)
#      JARS_DIR=/path/to/trino-server/plugin/oracle ./run.sh
#   2) 지정 안 하면 Maven Central에서 23.3.0.23.09 자동 다운로드 (Trino 475 번들 버전)
set -euo pipefail
cd "$(dirname "$0")"

UCP_VERSION=23.3.0.23.09

command -v javac >/dev/null || { echo "ERROR: JDK(javac)가 필요합니다"; exit 1; }
command -v python3 >/dev/null || { echo "ERROR: python3가 필요합니다"; exit 1; }

# --- jar 준비 ---
if [[ -n "${JARS_DIR:-}" ]]; then
    OJDBC=$(ls "$JARS_DIR"/ojdbc*.jar | head -1)
    UCP=$(ls "$JARS_DIR"/ucp*.jar | head -1)
    echo "운영 jar 사용: $OJDBC / $UCP"
else
    OJDBC=ojdbc11.jar
    UCP=ucp.jar
    [[ -f $OJDBC ]] || curl -sL -o $OJDBC "https://repo1.maven.org/maven2/com/oracle/database/jdbc/ojdbc11/$UCP_VERSION/ojdbc11-$UCP_VERSION.jar"
    [[ -f $UCP ]] || curl -sL -o $UCP "https://repo1.maven.org/maven2/com/oracle/database/jdbc/ucp/$UCP_VERSION/ucp-$UCP_VERSION.jar"
    echo "Maven Central jar 사용 ($UCP_VERSION)"
fi
CP=".:$OJDBC:$UCP"

javac -cp "$CP" UcpOverloadRepro.java UcpPoisonState.java

cleanup() { [[ -n "${LPID:-}" ]] && kill "$LPID" 2>/dev/null || true; }
trap cleanup EXIT

filter() { grep -vE "^[A-Z][a-z]{2} [0-9]|^INFO|^WARNING|^\s+at |^\s+\.\.\." || true; }

echo
echo "===================================================================="
echo "실험 1a: 리스너 다운 (연결 거부) - 과부하만으로 45203이 나오는가?"
echo "===================================================================="
java -cp "$CP" UcpOverloadRepro 15299 8 3 2>&1 | filter | tail -5

echo
echo "===================================================================="
echo "실험 1b: 리스너 과부하 (accept 후 즉시 끊음)"
echo "===================================================================="
python3 fake_listener.py drop 15298 & LPID=$!
sleep 1
java -cp "$CP" UcpOverloadRepro 15298 8 3 2>&1 | filter | tail -5
kill $LPID 2>/dev/null; LPID=

echo
echo "===================================================================="
echo "실험 1c: 서버 무응답 (행/타임아웃)"
echo "===================================================================="
python3 fake_listener.py hang 15297 & LPID=$!
sleep 1
java -cp "$CP" UcpOverloadRepro 15297 4 2 2>&1 | filter | tail -4
kill $LPID 2>/dev/null; LPID=

echo
echo "===================================================================="
echo "실험 2: 풀 생성 중 Error(OOM) 상태 재현 - UCP-45203 발생 검증"
echo "===================================================================="
python3 fake_listener.py drop 15296 & LPID=$!
sleep 1
java -cp "$CP" UcpPoisonState 15296 2>&1 | filter
kill $LPID 2>/dev/null; LPID=

echo
echo "===================================================================="
echo "판정 기준"
echo "  실험 1a/1b/1c: 'UCP-45203=0건' 이어야 함 (과부하 자체는 45203 원인 아님)"
echo "                 에러는 UCP-0 <- UCP-45257 <- ORA-* 형태"
echo "  실험 2:        2차/3차 시도에서 UCP-0 <- UCP-45203 이 나오면"
echo "                 '풀 생성 중 Error -> 영구 오염' 가설 입증"
echo "===================================================================="
