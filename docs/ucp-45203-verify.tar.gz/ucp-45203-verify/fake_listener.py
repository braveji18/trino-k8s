#!/usr/bin/env python3
"""과부하 상태의 Oracle 리스너를 모의하는 가짜 리스너.

모드:
  drop - TCP accept 후 즉시 종료 (리스너가 부하로 연결을 떨구는 상황)
  hang - TCP accept 후 무응답 (서버 포화/행 상황, 클라이언트 타임아웃 유발)
  (리스너 다운 상황은 이 스크립트 없이 미개방 포트로 테스트)

사용법: python3 fake_listener.py <drop|hang> <port>
"""
import socket
import sys
import threading
import time

mode = sys.argv[1]
port = int(sys.argv[2])

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(("127.0.0.1", port))
s.listen(128)
print(f"fake listener mode={mode} port={port}", flush=True)


def handle(conn):
    try:
        if mode == "drop":
            conn.close()
        elif mode == "hang":
            conn.recv(65536)
            time.sleep(3600)
    except Exception:
        pass


while True:
    conn, _ = s.accept()
    threading.Thread(target=handle, args=(conn,), daemon=True).start()
