# UCP-45203 검증 실험

Trino Oracle 커넥터에서 발생한 아래 오류의 원인을 검증하는 실험 코드.

```
java.sql.SQLException: UCP-0: Unable to start the Universal Connection Pool
Caused by: oracle.ucp.UniversalConnectionPoolException: UCP-45203: The Connection Request Info is null
```

## 검증 대상 가설

1. **실험 1 (반증 실험)**: 네트워크/리스너 과부하만으로는 UCP-45203이 발생하지 않는다.
   과부하의 실제 시그니처는 `UCP-0 ← UCP-45257 ← ORA-*` 계열이다.
2. **실험 2 (입증 실험)**: 풀 생성 도중 `Error`(예: OutOfMemoryError)가 발생하면 —
   UCP의 실패 정리 코드가 `catch (Exception)`이라 Error를 놓침 —
   자격증명 정보(CRI)가 없는 풀 객체가 남고, 이후 모든 연결 시도가
   `UCP-0 ← UCP-45203`으로 **영구 실패**한다 (JVM 재시작 전까지).
   user/password가 정상 설정되어 있어도 발생한다.

## 요구 사항

- JDK 17+ (javac 포함), python3, curl
- 네트워크 (Maven Central에서 ojdbc11/ucp 23.3.0.23.09 다운로드 — Trino 475 번들 버전)
- 실제 Oracle DB는 **필요 없음** (모의 리스너 사용)

## 실행 방법

```bash
cd ucp-45203-verify
./run.sh
```

운영 Trino와 동일한 드라이버 버전으로 검증하려면 (권장):

```bash
JARS_DIR=/path/to/trino-server/plugin/oracle ./run.sh
```

개별 실험만 실행:

```bash
# 컴파일
javac -cp .:ojdbc11.jar:ucp.jar UcpOverloadRepro.java UcpPoisonState.java

# 실험 1b: 리스너 과부하 모의 (별도 터미널에서 리스너 먼저)
python3 fake_listener.py drop 15298 &
java -cp .:ojdbc11.jar:ucp.jar UcpOverloadRepro 15298 8 3

# 실험 2: 풀 오염 → 45203 재현
python3 fake_listener.py drop 15296 &
java -cp .:ojdbc11.jar:ucp.jar UcpPoisonState 15296
```

## 기대 결과 (2026-07-06 UCP 23.3.0.23.09에서 확인됨)

| 실험 | 결과 |
|---|---|
| 1a 리스너 다운 | `UCP-45203=0건`, 모두 `UCP-45257 ← ORA-12541` |
| 1b 연결 즉시 끊김 | `UCP-45203=0건`, 모두 `UCP-45257 ← ORA-17002/17800` |
| 1c 무응답(타임아웃) | `UCP-45203=0건`, 모두 `UCP-45257 ← ORA-17002 read timeout` |
| 2 풀 생성 중 Error 상태 | 2차/3차 시도에서 **`UCP-0 ← UCP-45203`** 영구 반복 → 가설 입증 |

## 실험 2의 시뮬레이션 방식에 대한 주석

실제 OOM을 UCP 내부의 정확한 지점에 주입하는 대신, Error가 남기는 상태
(풀 객체 존재 + `defaultConnectionRetrievalInfo == null`)를 리플렉션으로 재현한다.
"Error가 이 상태를 만든다"는 부분은 UCP 23.3.0.23.09 디컴파일로 확인:

- `oracle.ucp.jdbc.PoolDataSourceImpl.createUniversalConnectionPool()`:
  `this.connectionPool` 할당(`createPoolWithDefaultProperties()`) 후 여러 설정 단계를
  거쳐 **맨 마지막에** `setConnectionRetrievalInfo(user/password)` 호출.
  실패 정리는 `catch (Exception exc) { this.connectionPool = null; ... }` — Error 미포함.
- `oracle.ucp.common.UniversalConnectionPoolBase`: `defaultConnectionRetrievalInfo`
  초기값 null, lifecycle 초기값 `LIFE_CYCLE_STOPPED`.
- `startPool()`: 풀 객체가 있으면 생성을 건너뛰고 `start()`만 재시도 →
  `start()` 진입부에서 CRI null이면 `UCP_COMMON_CRI_NULL(45203)` throw →
  `UCP-0` SQLException으로 래핑. CRI를 다시 설정하는 경로는 없음 → 영구 오염.

## 운영 환경에서의 함의

- UCP-45203 발생 = 해당 노드 JVM에서 풀 생성 도중 Error(대개 OOM)가 있었다는 신호.
  당시 GC/OOM 로그 확인 권장.
- 복구는 해당 Trino 프로세스 재시작뿐.
- 예방: `oracle.connection-pool.enabled=false` (Trino 자체 재시도로 충분),
  워커 메모리 압박 관리.
