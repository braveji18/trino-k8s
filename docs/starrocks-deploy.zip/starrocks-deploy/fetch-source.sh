#!/usr/bin/env bash
# StarRocks operator 원본에서 필요한 3개 파일만 가져와 base에 배치한다.
# 사용법: ./fetch-source.sh [git-tag]   예) ./fetch-source.sh v1.11.7
set -euo pipefail

TAG="${1:-v1.11.7}"
REPO="https://github.com/StarRocks/starrocks-kubernetes-operator.git"
TMP="$(mktemp -d)"

echo ">> ${TAG} 태그로 원본 클론 중..."
git clone --depth 1 --branch "${TAG}" "${REPO}" "${TMP}"

echo ">> 실체 파일 복사 (CRD 심볼릭 링크 아님, deploy/ 원본 사용)"
cp "${TMP}/deploy/starrocks.com_starrocksclusters.yaml" base/operator/crd.yaml
cp "${TMP}/deploy/operator.yaml"                          base/operator/operator.yaml

echo ">> 정리"
rm -rf "${TMP}"
echo "완료. base/operator/crd.yaml, base/operator/operator.yaml 갱신됨."
echo "operator 이미지 태그가 ${TAG}와 일치하는지 base/operator/kustomization.yaml 에서 확인하세요."
