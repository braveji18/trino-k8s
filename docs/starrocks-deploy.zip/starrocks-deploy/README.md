# starrocks-deploy

StarRocks Kubernetes Operator를 **사내 Git + ArgoCD + Kustomize**로 배포하기 위한 저장소.

## 구조
- `base/operator` : CRD + Operator (환경 무관 공통)
- `base/cluster`  : StarRocksCluster CR 기본형
- `overlays/<env>`: 환경별 patch (prod / staging / dev)
- `argocd/`       : ArgoCD Application / ApplicationSet
- `fetch-source.sh`: 원본에서 CRD·operator.yaml 갱신 스크립트

## 빠른 시작
```bash
# 1) 원본 소스 갱신 (원하는 태그 지정)
./fetch-source.sh v1.11.7

# 2) 사내 레지스트리로 이미지 경로 수정
#    - base/operator/kustomization.yaml 의 images:
#    - overlays/<env>/patch-cluster.yaml 의 image:

# 3) 로컬 렌더링 검증
kustomize build base/operator
kustomize build overlays/prod

# 4) 사내 git에 push 후 ArgoCD에 등록
kubectl apply -f argocd/app-operator.yaml
kubectl apply -f argocd/app-cluster-prod.yaml
```

## 주의
- CRD가 약 330KB → ArgoCD `ServerSideApply=true` 필수
- CR 이미지는 `images:`로 안 바뀜 → overlay patch로 교체
- FE는 프로덕션에서 3대 미만 금지 (쿼럼)
